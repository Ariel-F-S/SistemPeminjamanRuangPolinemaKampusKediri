from PyQt5 import QtWidgets, QtGui

from ui.kelola_akun_admin import Ui_MainWindow as KelolaAkunUI
from model.User import User

from controller.dashboard_admin import HalamanAdmin
from controller.admin_monitoring_ruang import AdminMonitoringRuang
from controller.admin_monitoring_pengajuan import AdminMonitoringPengajuan
from controller.admin_monitoring_peminjaman import AdminMonitoringPeminjaman

from controller.dialog_tambah_akun import TambahAkun
from controller.dialog_ubah_akun import UbahAkun


class AdminKelolaAkun(QtWidgets.QMainWindow, KelolaAkunUI):

    def __init__(self):
        super().__init__()
        self.setupUi(self)

        self.user = User()

        # =========================
        # MODEL TABEL
        # =========================

        self.model = QtGui.QStandardItemModel()
        self.tableView.setModel(self.model)

        # =========================
        # TOMBOL NAVIGASI
        # =========================

        self.pushButton.clicked.connect(self.dashboard)
        self.pushButton_2.clicked.connect(self.kelola_akun)
        self.pushButton_3.clicked.connect(self.data_ruang)
        self.pushButton_4.clicked.connect(self.pengajuan)
        self.pushButton_5.clicked.connect(self.data_peminjaman)
        self.pushButton_6.clicked.connect(self.keluar)

        # =========================
        # TOMBOL KELOLA AKUN
        # =========================

        self.pushButton_7.clicked.connect(self.cari_akun)
        self.pushButton_8.clicked.connect(self.tambah_akun)
        self.pushButton_9.clicked.connect(self.ubah_akun)
        self.pushButton_10.clicked.connect(self.hapus_akun)

        # =========================
        # FILTER AKUN
        # =========================

        self.comboBox.addItem("Semua")
        self.comboBox.addItem("Admin")
        self.comboBox.addItem("BMN")
        self.comboBox.addItem("OKI")

        # tampilkan data
        self.tampilkan_data()

    # ==================================================
    # NAVIGASI
    # ==================================================

    def dashboard(self):
        self.halaman = HalamanAdmin()
        self.halaman.show()
        self.close()

    def kelola_akun(self):
        self.halaman = AdminKelolaAkun()
        self.halaman.show()
        self.close()

    def data_ruang(self):
        self.halaman = AdminMonitoringRuang()
        self.halaman.show()
        self.close()

    def pengajuan(self):
        self.halaman = AdminMonitoringPengajuan()
        self.halaman.show()
        self.close()

    def data_peminjaman(self):
        self.halaman = AdminMonitoringPeminjaman()
        self.halaman.show()
        self.close()

    def keluar(self):

        pesan = QtWidgets.QMessageBox.question(
            self,
            "Konfirmasi Logout",
            "Apakah Anda yakin ingin keluar?",
            QtWidgets.QMessageBox.Yes |
            QtWidgets.QMessageBox.No
        )

        if pesan == QtWidgets.QMessageBox.Yes:
            self.close()

    def tampilkan_data(self):

        data = self.user.get_Data()

        self.model.clear()

        if not data:
            return

        jumlah_kolom = len(data[0])
        header = []

        for i in range(jumlah_kolom):
            header.append(f"Kolom {i + 1}")

        self.model.setHorizontalHeaderLabels(header)

        for row_data in data:

            items = []

            for nilai in row_data:
                items.append(
                    QtGui.QStandardItem(str(nilai))
                )

            self.model.appendRow(items)

        self.tableView.resizeColumnsToContents()

    def tambah_akun(self):

        self.dialog = TambahAkun()
        self.dialog.exec_()

        self.tampilkan_data()

    def ubah_akun(self):

        index = self.tableView.currentIndex()

        if not index.isValid():
            QtWidgets.QMessageBox.warning(
                self,
                "Peringatan",
                "Silakan pilih akun yang ingin diubah."
            )
            return

        id_user = self.model.item(
            index.row(),
            0
        ).text()

        self.dialog = UbahAkun(id_user)
        self.dialog.exec_()

        self.tampilkan_data()

    def hapus_akun(self):

        index = self.tableView.currentIndex()

        if not index.isValid():
            QtWidgets.QMessageBox.warning(
                self,
                "Peringatan",
                "Silakan pilih akun yang ingin dihapus."
            )
            return

        id_user = self.model.item(
            index.row(),
            0
        ).text()

        konfirmasi = QtWidgets.QMessageBox.question(
            self,
            "Konfirmasi Hapus",
            "Apakah Anda yakin ingin menghapus akun ini?",
            QtWidgets.QMessageBox.Yes |
            QtWidgets.QMessageBox.No
        )

        if konfirmasi == QtWidgets.QMessageBox.Yes:

            self.user.delete(id_user)

            QtWidgets.QMessageBox.information(
                self,
                "Berhasil",
                "Akun berhasil dihapus."
            )

            self.tampilkan_data()

    def cari_akun(self):

        keyword = self.lineEdit.text().strip()
        role = self.comboBox.currentText()

        data = self.user.get_Data()

        self.model.clear()

        if not data:
            return

        header = []

        for i in range(len(data[0])):
            header.append(f"Kolom {i + 1}")

        self.model.setHorizontalHeaderLabels(header)

        for row_data in data:

            teks_data = " ".join(
                str(nilai).lower()
                for nilai in row_data
            )

            if keyword.lower() not in teks_data:
                continue

            if role != "Semua":

                if role.lower() not in teks_data:
                    continue

            items = []

            for nilai in row_data:
                items.append(
                    QtGui.QStandardItem(str(nilai))
                )

            self.model.appendRow(items)

        self.tableView.resizeColumnsToContents()